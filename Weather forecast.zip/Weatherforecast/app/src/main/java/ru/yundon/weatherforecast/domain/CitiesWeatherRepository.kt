package ru.yundon.weatherforecast.domain

import kotlinx.coroutines.flow.Flow
import ru.yundon.weatherforecast.domain.model.CityWeatherItem

interface CitiesWeatherRepository {

    fun getCitiesWeatherList(): Flow<List<CityWeatherItem>>

    suspend fun getCitiesWeatherItem(name: String): CityWeatherItem

    suspend fun requestCitiesWeather(city: String)
}