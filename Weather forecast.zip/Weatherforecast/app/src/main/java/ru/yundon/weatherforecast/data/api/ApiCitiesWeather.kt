package ru.yundon.weatherforecast.data.api

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query
import ru.yundon.weatherforecast.data.api.apimodel.CitiesWeatherInfo

interface ApiCitiesWeather {

    @GET("data/2.5/weather?appid=77b25b683547c602c1484577e67bb360&units=metric&lang=ru")
    suspend fun getCitiesWeatherInfo(@Query("city") city: String): Response<CitiesWeatherInfo>
}