package ru.yundon.weatherforecast.presentation

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import ru.yundon.weatherforecast.domain.usecases.DataRequestCitiesWeatherUseCase
import ru.yundon.weatherforecast.domain.usecases.GetCitiesWeatherListUseCase
import ru.yundon.weatherforecast.domain.usecases.GetCityWeatherByNameUseCase

class MainViewModel(
    getCitiesWeatherListUseCase: GetCitiesWeatherListUseCase,
    private val getCityWeatherByNameUseCase: GetCityWeatherByNameUseCase,
    private val requestCitiesWeatherUseCase: DataRequestCitiesWeatherUseCase
): ViewModel() {

    init {
        Log.d("MyTag", "VM CREATED")
    }

    val citiesWeatherList = getCitiesWeatherListUseCase.getCitiesWeatherList().asLiveData()

    fun requestCitiesWeatherInfo(){

        viewModelScope.launch(Dispatchers.IO) {
            requestCitiesWeatherUseCase.requestCitiesWeather()
            Log.d("MyTag", "ViewModel - запрос на сайт")
        }
    }
}