package ru.yundon.weatherforecast.domain.usecases

import ru.yundon.weatherforecast.domain.CitiesWeatherRepository
import ru.yundon.weatherforecast.domain.model.CityWeatherItem

class GetCityWeatherByNameUseCase(private val citiesWeatherRepository: CitiesWeatherRepository) {

    suspend fun getCitiesWeatherItemById(name: String): CityWeatherItem{
        return citiesWeatherRepository.getCitiesWeatherItem(name)
    }
}