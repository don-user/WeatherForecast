package ru.yundon.weatherforecast.utils

internal enum class Cities {
    MOSCOW,
    KRASNODAR,
    NOVOSIBIRSK,
    CHELYABINSK,
    ELISTA,
    GROZNY,
    IRKUTSK,
    MURMANSK,
    OMSK,
    SAMARA,
    SOCHI,
    TYUMEN,
    USSURIYSK,
    VLADIVOSTOK,
    IVANOVO
}