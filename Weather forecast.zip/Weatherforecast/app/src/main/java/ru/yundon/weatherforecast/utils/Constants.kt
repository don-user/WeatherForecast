package ru.yundon.weatherforecast.utils

object Constants {
    const val BASE_URL = "https://api.openweathermap.org/"
    const val CONNECTION_ERROR = "Ошибка соеденение с свервером, проверьте интернет соеденение"
    const val DATABASE_VERSION_1 = 1




}