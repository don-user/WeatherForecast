package ru.yundon.weatherforecast.domain.usecases

import kotlinx.coroutines.flow.Flow
import ru.yundon.weatherforecast.domain.CitiesWeatherRepository
import ru.yundon.weatherforecast.domain.model.CityWeatherItem

class GetCitiesWeatherListUseCase (private val citiesWeatherRepository: CitiesWeatherRepository){

    fun getCitiesWeatherList(): Flow<List<CityWeatherItem>> {
        return citiesWeatherRepository.getCitiesWeatherList()
    }
}