package ru.yundon.weatherforecast.data.datarepository

import android.util.Log
import ru.yundon.weatherforecast.data.api.RemoteDataBase
import ru.yundon.weatherforecast.data.api.apimodel.CitiesWeatherInfo
import ru.yundon.weatherforecast.data.database.CitiesWeatherEntity

class CitiesWeatherRemoteStorage: RemoteDataBase() {

    suspend fun getCitiesWeatherList(city: String): CitiesWeatherEntity? {
        val cityWeather = getApiCitiesWeatherResult(city)
        Log.d("MyTag", "RemoteStorage запрос в сеть")
        return if (cityWeather != null) objectTransformation(cityWeather)
        else null
    }

    private fun objectTransformation(json: CitiesWeatherInfo): CitiesWeatherEntity {

        return CitiesWeatherEntity(
            json.name,
            json.main?.temp,
            json.main?.feelsLike,
            json.main?.humidity,
            json.main?.seaLevel,
            json.main?.grndLevel,
            json.wind?.speed,
            json.wind?.deg,
            json.weather[0].description,
            json.weather[0].icon,
            )
    }
}