package ru.yundon.weatherforecast.data.datarepository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import ru.yundon.weatherforecast.data.database.CitiesWeatherEntity
import ru.yundon.weatherforecast.domain.CitiesWeatherRepository
import ru.yundon.weatherforecast.domain.model.CityWeatherItem

class CitiesWeatherRepositoryImpl(
    private val localStorage: CitiesWeatherLocalStorage,
    private val removeStorage: CitiesWeatherRemoteStorage
) : CitiesWeatherRepository {


    override fun getCitiesWeatherList(): Flow<List<CityWeatherItem>> {

        val listCitiesWeather = localStorage.citiesWeatherList
        return mapListToDomain(listCitiesWeather)
    }

    override suspend fun getCitiesWeatherItem(name: String): CityWeatherItem {

        val cityWeather = localStorage.getCityWeatherInfoByName(name)
        return mapItemToDomain(cityWeather)
    }

    override suspend fun requestCitiesWeather(city: String) {

        val citiesWeatherInfo = removeStorage.getCitiesWeatherList(city)
        if (citiesWeatherInfo != null) {
            localStorage.insertCitiesIntoDatabase(citiesWeatherInfo)
        }
    }

    private fun mapListToDomain(listCitiesWeather: Flow<List<CitiesWeatherEntity>>): Flow<List<CityWeatherItem>> {
        return listCitiesWeather.map { list ->
            list.map {
                CityWeatherItem(
                    it.name,
                    it.temp,
                    it.feelsLike,
                    it.humidity,
                    it.seaLevel,
                    it.grndLevel,
                    it.windSpeed,
                    it.windDeg,
                    it.description,
                    it.icon
                )
            }
        }
    }
    private fun mapItemToDomain(item: CitiesWeatherEntity): CityWeatherItem{
        return CityWeatherItem(
            name = item.name,
            temp = item.temp,
            feelsLike = item.feelsLike,
            humidity = item.humidity,
            seaLevel = item.seaLevel,
            grndLevel = item.grndLevel,
            windSpeed = item.windSpeed,
            windDeg = item.windDeg,
            icone = item.icon,
            description = item.description
        )
    }
}