package ru.yundon.weatherforecast.di

import dagger.Module
import ru.yundon.weatherforecast.domain.CitiesWeatherRepository

@Module
class DataModule {

    fun provideCitiesWeatherRepository(): CitiesWeatherRepository {
        return 
    }
}