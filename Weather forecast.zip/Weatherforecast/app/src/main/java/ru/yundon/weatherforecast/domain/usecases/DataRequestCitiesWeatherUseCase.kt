package ru.yundon.weatherforecast.domain.usecases

import ru.yundon.weatherforecast.domain.CitiesWeatherRepository
import ru.yundon.weatherforecast.utils.Cities

class DataRequestCitiesWeatherUseCase(private val citiesWeatherRepository: CitiesWeatherRepository) {

    suspend fun requestCitiesWeather(){
        for (item in Cities.values()) citiesWeatherRepository.requestCitiesWeather(item.name)
    }
}